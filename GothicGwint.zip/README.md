Gothicowa gra karciana gwint. 
Uruchomienie poprzez main razem z main2 jeśli gra ma się odbyć na tym samym komputerze
